import os
import re
import psutil
import subprocess
import logging
import requests
from flask import Flask, request, jsonify, render_template
from telegram import Bot, Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
from dotenv import load_dotenv

# Загрузка токенов и ключей из .env
load_dotenv()
BOT_TOKEN = os.getenv('BOT_TOKEN')
WEBHOOK_URL = os.getenv('WEBHOOK_URL')  # URL вашего вебхука

if not BOT_TOKEN:
    raise ValueError("Токен не загружен! Проверьте файл .env.")

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
app = Flask(__name__)

# Логирование
logging.basicConfig(filename='app.log', level=logging.DEBUG)
app.logger.debug('Приложение загружено')

# Проверка IP-адреса
def is_valid_ip(ip):
    ip_regex = re.compile(r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$")
    try:
        return bool(ip_regex.match(ip))
    except ValueError:
        return False

# Главная страница
@app.route('/')
def home():
    return render_template('home.html')

# Страница инструментов
@app.route('/tools')
def tools():
    return render_template('tools.html')

# Страница инструментов для сканирования
@app.route('/tools/scantools')
def scantools():
    return render_template('scantools.html')

# Вебхук от Telegram
@app.route('/webapphook', methods=['POST'])
def webhook():
    data = request.get_json(force=True)
    if not data:
        return jsonify({'status': 'error', 'message': 'No data received'}), 400

    update = Update.de_json(data, bot)
    if update.message:
        chat_id = update.message.chat.id
        text = update.message.text

        # Пример ответа пользователю через Telegram API
        bot.send_message(chat_id=chat_id, text=f"Вы сказали: {text}")

    return jsonify({'status': 'success'}), 200

# Стартовая команда для Telegram бота
async def start(update: Update, context):
    await update.message.reply_text("Добро пожаловать в веб-приложение!")

# Обработка данных из Mini App
async def handle_webapp_data(update: Update, context):
    try:
        if update.message.web_app_data and update.message.web_app_data.data:
            data = update.message.web_app_data.data
            logging.info(f"Полученные данные из Mini App: {data}")
            await update.message.reply_text("Данные из Mini App успешно получены!")
        else:
            logging.error("Ошибка: данные не были получены.")
            await update.message.reply_text("Ошибка: данные не были получены.")
    except Exception as e:
        logging.error(f"Ошибка при обработке данных: {e}")
        await update.message.reply_text("Произошла ошибка при обработке данных.")

# Маршруты для запуска задач
@app.route('/run_task', methods=['POST'])
def run_task():
    task = request.form.get('task')
    if task == 'check_ports':
        result = check_ports()
    else:
        result = "Неизвестная задача"
    return jsonify({'result': result})

# Пример функции для проверки открытых портов
def check_ports():
    ports_info = []
    for conn in psutil.net_connections(kind='inet'):
        if conn.status == psutil.CONN_LISTEN:
            ports_info.append(f"IP: {conn.laddr.ip}, Port: {conn.laddr.port}")
    return ports_info

# Инициализация и настройка Telegram бота через Flask
def start_bot():
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler('start', start))
    application.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, handle_webapp_data))

    # Устанавливаем вебхук для обработки сообщений
    bot.set_webhook(WEBHOOK_URL)

# Запуск приложения
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=6969)
